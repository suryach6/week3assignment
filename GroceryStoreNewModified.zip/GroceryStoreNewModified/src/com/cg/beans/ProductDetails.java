package com.cg.beans;

public enum ProductDetails {
	GROCERIES, DAIRYPRODUCTS;
}
