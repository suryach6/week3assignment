package com.cg.beans;

public enum UserDetails {
	EMPLOYEE, AFFILIATE, CUSTOMER;
}
