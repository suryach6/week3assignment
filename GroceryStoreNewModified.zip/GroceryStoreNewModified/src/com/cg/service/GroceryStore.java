package com.cg.service;

import com.cg.beans.User;

public interface GroceryStore {

	public double calculateBill(User user);

}