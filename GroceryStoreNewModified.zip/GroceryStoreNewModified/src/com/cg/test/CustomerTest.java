package com.cg.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import org.junit.Test;

import com.cg.beans.Product;
import com.cg.beans.ProductDetails;
import com.cg.beans.User;
import com.cg.beans.UserDetails;
import com.cg.service.GroceryStore;
import com.cg.service.GroceryStoreImp;

class CustomerTest {

	@Test
	void test() {

		GroceryStore retail = new GroceryStoreImp();
		List<Product> list = new ArrayList<Product>();

		Product product = new Product();
		Product product1 = new Product();

		User user = new User();
		user.setUserId(45);
		user.setUserName("Krishna");
		user.setUsertype(UserDetails.CUSTOMER);
		user.setRegistrationDate(LocalDate.now());

		product.setProductId(5021);
		product.setProductName("Jowar");
		product.setProductType(ProductDetails.GROCERIES);
		product.setQuantity(15);
		product.setRatePerQuantity(45);

		list.add(product);

		product1.setProductId(100234);
		product1.setProductName("Curd");
		product1.setProductType(ProductDetails.DAIRYPRODUCTS);
		product1.setQuantity(2);
		product1.setRatePerQuantity(120);

		list.add(product1);
		user.setProduct(list);
		double bill = retail.calculateBill(user);
		System.out.println(bill);
		assertEquals(190, bill);
	}

}
